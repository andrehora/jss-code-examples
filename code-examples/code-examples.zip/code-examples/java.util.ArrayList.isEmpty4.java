public class test {
    public static void main(String[] args)
    {
      // Create an empty ArrayList.
        ArrayList myArrayList = new ArrayList();
		
	 // Test whether the array is empty or not.
        if (myArrayList.isEmpty())
        {
            System.out.println("The ArrayList is empty");
        }
        else
        {
            System.out.println("The ArrayList is not empty");
        }
    }
}