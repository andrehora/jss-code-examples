public int getValue(int input) {
	int[] data = {1,2,3,4,5};
	Preconditions.checkElementIndex(input,data.length, "Illegal Argument passed: Invalid index.");
	return 0;
}