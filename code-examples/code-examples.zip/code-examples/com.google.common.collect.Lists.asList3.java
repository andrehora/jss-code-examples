public static void main(String[] args) {
	Lists.newArrayList("Mike", "John", "Lesly");
	Lists.asList("A","B", new String [] {"C", "D"});
}