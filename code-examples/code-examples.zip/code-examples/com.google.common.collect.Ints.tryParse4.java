public static void main(String[] args) { 
	String numberAsString = "10"; 
	Integer value = Ints.tryParse(numberAsString);
}