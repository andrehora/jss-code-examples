public static void main(String[] args) {
	List<String> list1 = Lists.asList("1", new String[]{}); 
	List<String> list2 = Lists.asList("1", new String[]{"2"}); 
	List<String> list3 = Lists.asList("1", "2", new String[]{"3"});
}