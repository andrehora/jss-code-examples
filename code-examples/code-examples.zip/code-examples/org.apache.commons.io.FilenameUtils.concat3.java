path = FilenameUtils.concat(DATA_PATH, "sea_temp/") // set parent directory

featureBaseDir = FilenameUtils.concat(path, "features") // set feature directory
targetsBaseDir = FilenameUtils.concat(path, "targets") // set label directory
futureBaseDir = FilenameUtils.concat(path, "futures") // set futures directory