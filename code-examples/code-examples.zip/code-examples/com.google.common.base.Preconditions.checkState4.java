public void testState() {
	checkState(this.initialized, "Cannot perform action because not initialized.");
}