File shadow = new File(FilenameUtils.concat(targetFolder.getAbsolutePath(),
    sourceFile.getAbsolutePath().substring(prefixLength));