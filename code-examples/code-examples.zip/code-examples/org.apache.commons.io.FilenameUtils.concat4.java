assert org.apache.commons.io.FilenameUtils.concat("/home/bob", "work\\stuff.log") == 
"/home/bob/work/stuff.log"