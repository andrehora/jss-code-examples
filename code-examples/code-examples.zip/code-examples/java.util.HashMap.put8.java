public Map<String, ? extends FilterRegistration> getFilterRegistrations()
{
    if (!_enabled)
        throw new UnsupportedOperationException();

    HashMap<String, FilterRegistration> registrations = new HashMap<String, FilterRegistration>();
    ServletHandler handler=ServletContextHandler.this.getServletHandler();
    FilterHolder[] holders=handler.getFilters();
    if (holders!=null)
    {
        for (FilterHolder holder : holders)
            registrations.put(holder.getName(),holder.getRegistration());
    }
    return registrations;
}