public static void main (String[] args) {
	Lists.charactersOf("String")                                 // Guava
	Lists.newArrayList(Splitter.fixedLength(1).split("String"))  // Guava
}