public void setAcceptableCodes(final int[] acceptableCodes) {
    this.acceptableCodes = Ints.asList(acceptableCodes);
}