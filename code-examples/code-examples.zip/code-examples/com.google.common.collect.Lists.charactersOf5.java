public class StringtoCharListTest {

  public static void main(String[] args) {
    List<Character> charList = Lists.charactersOf("BE THE CODER");
    System.out.println(charList);
  }

}