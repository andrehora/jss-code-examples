class ArrayUtils
{
	public static void main(String[] args)
	{
		int arr[] = { 1, 2, 3, 4, 5 };

		List<Integer> list = Ints.asList(arr);
		System.out.println(list);
	}
}