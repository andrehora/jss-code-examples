public static void main(String[] args) { 
	List<Integer> list = ...;
	int[] values = Ints.toArray(list);
}