if(FilenameUtils.isExtension(file.getName(),"java")) {
    someoperation();
}