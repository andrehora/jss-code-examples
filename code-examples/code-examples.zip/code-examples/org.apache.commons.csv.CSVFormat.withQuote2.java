public static void main (String[] args) {
	CSVFormat.EXCEL.newFormat(',').withQuote('"')
}