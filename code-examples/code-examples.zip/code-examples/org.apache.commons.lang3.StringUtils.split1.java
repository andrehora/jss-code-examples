StringUtils.split(null)       = null
StringUtils.split("")         = []
StringUtils.split("abc def")  = ["abc", "def"]
StringUtils.split("abc  def") = ["abc", "def"]
StringUtils.split(" abc ")    = ["abc"]