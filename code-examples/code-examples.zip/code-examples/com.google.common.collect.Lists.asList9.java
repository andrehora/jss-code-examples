public static <E> List<E> asList(E first, E[] rest) {
	return Lists.asList(first, rest);
}