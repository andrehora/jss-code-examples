public String getExtensionByApacheCommonLib(String filename) {
    return FilenameUtils.getExtension(filename);
}